=======================================================
Short readme on how to compile libtremor.lib on Symbian
=======================================================

1. extract/SVN checkout into dir

2. copy this 'epoc' dir into it

3. exec in 'epoc' dir:
     bldmake bldfiles
     abld build

4. You are done! libtremor.lib should be compiled.

=======================================================
Enjoy! Grtz from SumthinWicked@users.sourceforge.net
=======================================================
