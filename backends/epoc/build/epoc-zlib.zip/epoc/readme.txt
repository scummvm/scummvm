====================================================
Short readme on how to compile zlib.lib on Symbian
====================================================

1. extract into dir libmad-0.x.x at the same level as
   the EScummVM source dir

2. copy this 'epoc' dir into it

3. check that libmad.mmp references the correct dir
   on this line: (the build system does not like '+'
   characters in dir names)
   
   SYSTEMINCLUDE   ..\msvc 
   
4. you might wanna check the FPM_XXX var declaration
   for the right architecture. (will probably work the
   first time)
   
5. exec in 'epoc' dir:
     bldmake bldfiles
     abld build

6. You are done! zlib.lib should be compiled.

====================================================
Enjoy! Grtz from SumthinWicked@users.sourceforge.net
====================================================
